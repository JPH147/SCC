<?php

include_once '../entities/seguimiento.php';

Class Creditos{

    private $conn;
    private $Seguimiento;

    public $id;
    public $id_credito;
    public $cliente;
    public $tipo_credito;
    public $fecha_inicio;
    public $fecha_fin;
    public $estado;
    public $documentos;

    public $monto;
    public $capital;
    public $interes;
    public $fecha;
    public $tiempo;
    public $total_pagado;
    public $total_cuotas;
    public $codigo;
    public $numero;
    public $id_courier;
    public $courier;
    public $numero_seguimiento;
    public $id_credito_refinanciado;
    public $credito_refinanciado;
    public $sucursal;
    public $fecha_credito;
    public $autorizador;
    public $vendedor;
    public $cliente_direccion;
    public $cliente_telefono;
    public $cliente_cargo;
    public $cliente_trabajo;
    public $tipo_pago;
    public $cuotas;
    public $total;
    public $pdf_foto;
    public $pdf_dni;
    public $pdf_cip;
    public $pdf_planilla;
    public $pdf_voucher;
    public $pdf_recibo;
    public $pdf_casilla;
    public $pdf_transaccion;
    public $pdf_autorizacion;
    public $pdf_tarjeta;
    public $pdf_compromiso;
    public $pdf_letra;
    public $pdf_ddjj;
    public $pdf_otros;
    public $observacion;

    public $garante;
    public $cronograma;
    public $orden;
    public $numero_pagina;
    public $total_pagina;

    public function __construct($db){
        $this->conn = $db;
        $this->Seguimiento = new Seguimiento($db);
    }

    function read(){

        $query = "CALL sp_listarcredito(?,?,?,?,?,?,?,?,?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->cliente);
        $result->bindParam(2, $this->tipo_credito);
        $result->bindParam(3, $this->documentos);
        $result->bindParam(4, $this->fecha_inicio);
        $result->bindParam(5, $this->fecha_fin);
        $result->bindParam(6, $this->estado);
        $result->bindParam(7, $this->numero_pagina);
        $result->bindParam(8, $this->total_pagina);
        $result->bindParam(9, $this->orden);

        $result->execute();
        
        $credito_list=array();
        $credito_list["creditos"]=array();

        $contador = $this->total_pagina*($this->numero_pagina-1);
        
        while($row = $result->fetch(PDO::FETCH_ASSOC))
        {
            extract($row);
            $contador=$contador+1;
            $items = array (
                "numero"=>$contador,
                "id"=>$id,
                "codigo"=>$codigo,
                "numero_credito"=>$numero,
                "institucion"=>$institucion,
                "sede"=>$sede,
                "subsede"=>$subsede,
                "id_cliente"=>$id_cliente,
                "cliente_nombre"=>$cliente_nombre,
                "fecha"=>$fecha,
                "tipo_pago"=>$tipo_pago,
                "numero_cuotas"=>$numero_cuotas,
                "monto_total"=>$monto_total,
                "id_tipo_credito"=>$id_tipo_credito,
                "tipo_credito"=>$tipo_credito,
                "observaciones"=>$observaciones,
                "documentos_adjuntos"=>$documentos_adjuntos,
                "documentos_totales"=>$documentos_totales,
                "estado"=>$estado,
            );
            array_push($credito_list["creditos"],$items);
        }

        return $credito_list;
    }

    function contar(){

        $query = "CALL sp_listarcreditocontar(?,?,?,?,?,?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->cliente);
        $result->bindParam(2, $this->tipo_credito);
        $result->bindParam(3, $this->documentos);
        $result->bindParam(4, $this->fecha_inicio);
        $result->bindParam(5, $this->fecha_fin);
        $result->bindParam(6, $this->estado);

        $result->execute();

        $row = $result->fetch(PDO::FETCH_ASSOC);

        $this->total_resultado=$row['total'];

        return $this->total_resultado;
    }

    function readxId(){

        $query ="call sp_listarcreditoxId(?)";
        
        $result = $this->conn->prepare($query);
        
        $result->bindParam(1, $this->id_credito);

        $Courier=$this->Seguimiento->readxdocumento_export(2,$this->id_credito);
        $Garantes=$this->read_garantes($this->id_credito);
        $Cronograma=$this->read_cronograma($this->id_credito);

        $result->execute();
    
        $row = $result->fetch(PDO::FETCH_ASSOC);

        $this->id_tipo = $row['id_tipo'];
        $this->tipo = $row['tipo'];
        $this->id_sucursal = $row['id_sucursal'];
        $this->sucursal = $row['sucursal'];
        $this->fecha = $row['fecha'];
        $this->codigo = $row['codigo'];
        $this->numero = $row['numero'];
        $this->id_autorizador = $row['id_autorizador'];
        $this->autorizador = $row['autorizador'];
        $this->id_vendedor = $row['id_vendedor'];
        $this->vendedor = $row['vendedor'];
        $this->id_cliente = $row['id_cliente'];
        $this->cliente = $row['cliente'];
        $this->cliente_direccion = $row['cliente_direccion'];
        $this->cliente_telefono = $row['cliente_telefono'];
        $this->cliente_cargo = $row['cliente_cargo'];
        $this->cliente_trabajo = $row['cliente_trabajo'];
        $this->id_tipo_pago = $row['id_tipo_pago'];
        $this->tipo_pago = $row['tipo_pago'];
        $this->fecha_pago = $row['fecha_pago'];
        $this->interes = $row['interes'];
        $this->capital = $row['capital'];
        $this->numero_cuotas = $row['numero_cuotas'];
        $this->total = $row['total'];
        $this->pdf_foto = $row['pdf_foto'];
        $this->pdf_dni = $row['pdf_dni'];
        $this->pdf_cip = $row['pdf_cip'];
        $this->pdf_planilla = $row['pdf_planilla'];
        $this->pdf_voucher = $row['pdf_voucher'];
        $this->pdf_recibo = $row['pdf_recibo'];
        $this->pdf_casilla = $row['pdf_casilla'];
        $this->pdf_transaccion = $row['pdf_transaccion'];
        $this->pdf_autorizacion = $row['pdf_autorizacion'];
        $this->pdf_tarjeta = $row['pdf_tarjeta'];
        $this->pdf_compromiso = $row['pdf_compromiso'];
        $this->pdf_letra = $row['pdf_letra'];
        $this->pdf_ddjj = $row['pdf_ddjj'];
        $this->pdf_otros = $row['pdf_otros'];
        $this->observaciones = $row['observaciones'];
        $this->id_credito_refinanciado = $row['id_credito_refinanciado'];
        $this->credito_refinanciado = $row['credito_refinanciado'];
        $this->id_estado = $row['id_estado'];
        $this->estado = $row['estado'];
        $this->courier = $Courier;
        $this->garante = $Garantes;
        $this->cronograma = $Cronograma;
    }

    function read_garantes(){

        $query = "CALL sp_listarcreditogarante(?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->id_credito);

        $result->execute();
        
        $transaccion_list=array();
        $transaccion_list["garantes"]=array();
        
        while($row = $result->fetch(PDO::FETCH_ASSOC))
        {
            extract($row);
            $transaccion_item = array (
                "id"=>$id,
                "id_cliente"=>$id_cliente,
                "cliente_dni"=>$cliente_dni,
                "cliente_nombre"=>$cliente_nombre,
                "cliente_telefono"=>$cliente_telefono,
                "cliente_direccion"=>$cliente_direccion,
                "dni_pdf"=>$dni_pdf,
                "cip_pdf"=>$cip_pdf,
                "planilla_pdf"=>$planilla_pdf,
            );
            array_push($transaccion_list["garantes"],$transaccion_item);
        }

        return $transaccion_list;
    }

    function read_cronogramaxId(){

        $query = "CALL sp_listarcreditocronogramaxId(?, ?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->id_credito);
        $result->bindParam(2, $this->orden);

        $result->execute();
        
        $credito_list=array();
        $credito_list["creditos"]=array();
        $contador = 0;

        while($row = $result->fetch(PDO::FETCH_ASSOC))
        {
            extract($row);
            $contador=$contador+1;
            $credito_item = array (
                "numero"=>$contador,
                "id_cronograma"=>$id_cronograma,
                "capital"=>$capital,
                "interes"=>$interes,
                "monto_cuota"=>$monto_cuota,
                "fecha_vencimiento"=>$fecha_vencimiento,
                "monto_interes"=>$monto_interes,
                "monto_pagado"=>$monto_pagado,
                "fecha_cancelacion"=>$fecha_cancelacion,
                "monto_pendiente"=>$monto_pendiente,
                "estado"=>$estado,
            );
            array_push($credito_list["creditos"],$credito_item);
        }

        return $credito_list;
    }

    function read_cronograma(){

      $query = "CALL sp_listarcreditocronograma(?)";

      $result = $this->conn->prepare($query);

      $result->bindParam(1, $this->id_credito);

      $result->execute();
      
      $cronograma_list=array();
      $contador = 0;

      while($row = $result->fetch(PDO::FETCH_ASSOC))
      {
          extract($row);
          $contador=$contador+1;
          $cronograma_item = array (
              "numero"=>$contador,
              "id_cronograma"=>$id,
              "capital"=>$capital,
              "interes"=>$interes,
              "monto_cuota"=>$monto,
              "fecha_vencimiento"=>$fecha,
              "estado"=>$estado
          );
          array_push($cronograma_list,$cronograma_item);
      }

      return $cronograma_list;
    }

    function read_tipo(){
        $query = "CALL sp_listarcreditotipo()";

        $result = $this->conn->prepare($query);
  
        $result->execute();
        
        $tipo_credito=array();
  
        while($row = $result->fetch(PDO::FETCH_ASSOC))
        {
            extract($row);
            $tipo_item = array (
                "id"=>$id,
                "nombre"=>$nombre,
            );
            array_push($tipo_credito,$tipo_item);
        }
  
        return $tipo_credito;
    }

    function crear(){
        $query = "CALL sp_crearcredito(
            :prtipo,
            :prsucursal,
            :prfecha,
            :prcodigo,
            :prnumero,
            :prautorizador,
            :prvendedor,
            :prcliente,
            :prclientedireccion,
            :prclientetelefono,
            :prclientecargo,
            :prclientetrabajo,
            :prtipopago,
            :prfechapago,
            :printeres,
            :prcapital,
            :prcuotas,
            :prtotal,
            :prpdffoto,
            :prpdfdni,
            :prpdfcip,
            :prpdfplanilla,
            :prpdfvoucher,
            :prpdfrecibo,
            :prpdfcasilla,
            :prpdftransaccion,
            :prpdfautorizacion,
            :prpdftarjeta,
            :prpdfcompromiso,
            :prpdfletra,
            :prpdfddjj,
            :pdfotros,
            :probservacion
        )";

        $result = $this->conn->prepare($query);

        $result->bindParam(":prtipo", $this->tipo_credito);
        $result->bindParam(":prsucursal", $this->sucursal);
        $result->bindParam(":prfecha", $this->fecha_credito);
        $result->bindParam(":prcodigo", $this->codigo);
        $result->bindParam(":prnumero", $this->numero);
        $result->bindParam(":prautorizador", $this->autorizador);
        $result->bindParam(":prvendedor", $this->vendedor);
        $result->bindParam(":prcliente", $this->cliente);
        $result->bindParam(":prclientedireccion", $this->cliente_direccion);
        $result->bindParam(":prclientetelefono", $this->cliente_telefono);
        $result->bindParam(":prclientecargo", $this->cliente_cargo);
        $result->bindParam(":prclientetrabajo", $this->cliente_trabajo);
        $result->bindParam(":prtipopago", $this->tipo_pago);
        $result->bindParam(":prfechapago", $this->fecha_pago);
        $result->bindParam(":printeres", $this->interes);
        $result->bindParam(":prcapital", $this->capital);
        $result->bindParam(":prcuotas", $this->cuotas);
        $result->bindParam(":prtotal", $this->total);
        $result->bindParam(":prpdffoto", $this->pdf_foto);
        $result->bindParam(":prpdfdni", $this->pdf_dni);
        $result->bindParam(":prpdfcip", $this->pdf_cip);
        $result->bindParam(":prpdfplanilla", $this->pdf_planilla);
        $result->bindParam(":prpdfvoucher", $this->pdf_voucher);
        $result->bindParam(":prpdfrecibo", $this->pdf_recibo);
        $result->bindParam(":prpdfcasilla", $this->pdf_casilla);
        $result->bindParam(":prpdftransaccion", $this->pdf_transaccion);
        $result->bindParam(":prpdfautorizacion", $this->pdf_autorizacion);
        $result->bindParam(":prpdftarjeta", $this->pdf_tarjeta);
        $result->bindParam(":prpdfcompromiso", $this->pdf_compromiso);
        $result->bindParam(":prpdfletra", $this->pdf_letra);
        $result->bindParam(":prpdfddjj", $this->pdf_ddjj);
        $result->bindParam(":pdfotros", $this->pdf_otros);
        $result->bindParam(":probservacion", $this->observacion);

        $this->tipo_credito=htmlspecialchars(strip_tags($this->tipo_credito));
        $this->sucursal=htmlspecialchars(strip_tags($this->sucursal));
        $this->fecha_credito=htmlspecialchars(strip_tags($this->fecha_credito));
        $this->codigo=htmlspecialchars(strip_tags($this->codigo));
        $this->numero=htmlspecialchars(strip_tags($this->numero));
        $this->autorizador=htmlspecialchars(strip_tags($this->autorizador));
        $this->vendedor=htmlspecialchars(strip_tags($this->vendedor));
        $this->cliente=htmlspecialchars(strip_tags($this->cliente));
        $this->cliente_direccion=htmlspecialchars(strip_tags($this->cliente_direccion));
        $this->cliente_telefono=htmlspecialchars(strip_tags($this->cliente_telefono));
        $this->cliente_cargo=htmlspecialchars(strip_tags($this->cliente_cargo));
        $this->cliente_trabajo=htmlspecialchars(strip_tags($this->cliente_trabajo));
        $this->tipo_pago=htmlspecialchars(strip_tags($this->tipo_pago));
        $this->fecha_pago=htmlspecialchars(strip_tags($this->fecha_pago));
        $this->interes=htmlspecialchars(strip_tags($this->interes));
        $this->capital=htmlspecialchars(strip_tags($this->capital));
        $this->cuotas=htmlspecialchars(strip_tags($this->cuotas));
        $this->total=htmlspecialchars(strip_tags($this->total));
        $this->pdf_foto=htmlspecialchars(strip_tags($this->pdf_foto));
        $this->pdf_dni=htmlspecialchars(strip_tags($this->pdf_dni));
        $this->pdf_cip=htmlspecialchars(strip_tags($this->pdf_cip));
        $this->pdf_planilla=htmlspecialchars(strip_tags($this->pdf_planilla));
        $this->pdf_voucher=htmlspecialchars(strip_tags($this->pdf_voucher));
        $this->pdf_recibo=htmlspecialchars(strip_tags($this->pdf_recibo));
        $this->pdf_casilla=htmlspecialchars(strip_tags($this->pdf_casilla));
        $this->pdf_transaccion=htmlspecialchars(strip_tags($this->pdf_transaccion));
        $this->pdf_autorizacion=htmlspecialchars(strip_tags($this->pdf_autorizacion));
        $this->pdf_tarjeta=htmlspecialchars(strip_tags($this->pdf_tarjeta));
        $this->pdf_compromiso=htmlspecialchars(strip_tags($this->pdf_compromiso));
        $this->pdf_letra=htmlspecialchars(strip_tags($this->pdf_letra));
        $this->pdf_ddjj=htmlspecialchars(strip_tags($this->pdf_ddjj));
        $this->pdf_otros=htmlspecialchars(strip_tags($this->pdf_otros));
        $this->observacion=htmlspecialchars(strip_tags($this->observacion));

        if($result->execute())
        {
            while($row = $result->fetch(PDO::FETCH_ASSOC))
            {
                extract($row);
                $this->id_credito=$id;
            }
            return true;
        }
        return false;
    }

    function actualizar(){
        $query = "CALL sp_actualizarcredito(
            :prcredito,
            :prsucursal,
            :prfecha,
            :prautorizador,
            :prvendedor,
            :prcliente,
            :prclientedireccion,
            :prclientetelefono,
            :prclientecargo,
            :prclientetrabajo,
            :prtipopago,
            :prfechapago,
            :printeres,
            :prcapital,
            :prcuotas,
            :prtotal,
            :prpdffoto,
            :prpdfdni,
            :prpdfcip,
            :prpdfplanilla,
            :prpdfvoucher,
            :prpdfrecibo,
            :prpdfcasilla,
            :prpdftransaccion,
            :prpdfautorizacion,
            :prpdftarjeta,
            :prpdfcompromiso,
            :prpdfletra,
            :prpdfddjj,
            :prpdfotros,
            :probservacion
        )";

        $result = $this->conn->prepare($query);

        $result->bindParam(":prcredito", $this->id_credito);
        $result->bindParam(":prsucursal", $this->sucursal);
        $result->bindParam(":prfecha", $this->fecha_credito);
        $result->bindParam(":prautorizador", $this->autorizador);
        $result->bindParam(":prvendedor", $this->vendedor);
        $result->bindParam(":prcliente", $this->cliente);
        $result->bindParam(":prclientedireccion", $this->cliente_direccion);
        $result->bindParam(":prclientetelefono", $this->cliente_telefono);
        $result->bindParam(":prclientecargo", $this->cliente_cargo);
        $result->bindParam(":prclientetrabajo", $this->cliente_trabajo);
        $result->bindParam(":prtipopago", $this->tipo_pago);
        $result->bindParam(":prfechapago", $this->fecha_pago);
        $result->bindParam(":printeres", $this->interes);
        $result->bindParam(":prcapital", $this->capital);
        $result->bindParam(":prcuotas", $this->cuotas);
        $result->bindParam(":prtotal", $this->total);
        $result->bindParam(":prpdffoto", $this->pdf_foto);
        $result->bindParam(":prpdfdni", $this->pdf_dni);
        $result->bindParam(":prpdfcip", $this->pdf_cip);
        $result->bindParam(":prpdfplanilla", $this->pdf_planilla);
        $result->bindParam(":prpdfvoucher", $this->pdf_voucher);
        $result->bindParam(":prpdfrecibo", $this->pdf_recibo);
        $result->bindParam(":prpdfcasilla", $this->pdf_casilla);
        $result->bindParam(":prpdftransaccion", $this->pdf_transaccion);
        $result->bindParam(":prpdfautorizacion", $this->pdf_autorizacion);
        $result->bindParam(":prpdftarjeta", $this->pdf_tarjeta);
        $result->bindParam(":prpdfcompromiso", $this->pdf_compromiso);
        $result->bindParam(":prpdfletra", $this->pdf_letra);
        $result->bindParam(":prpdfddjj", $this->pdf_ddjj);
        $result->bindParam(":prpdfotros", $this->pdf_otros);
        $result->bindParam(":probservacion", $this->observacion);

        $this->id_credito=htmlspecialchars(strip_tags($this->id_credito));
        $this->sucursal=htmlspecialchars(strip_tags($this->sucursal));
        $this->fecha_credito=htmlspecialchars(strip_tags($this->fecha_credito));
        $this->autorizador=htmlspecialchars(strip_tags($this->autorizador));
        $this->vendedor=htmlspecialchars(strip_tags($this->vendedor));
        $this->cliente=htmlspecialchars(strip_tags($this->cliente));
        $this->cliente_direccion=htmlspecialchars(strip_tags($this->cliente_direccion));
        $this->cliente_telefono=htmlspecialchars(strip_tags($this->cliente_telefono));
        $this->cliente_cargo=htmlspecialchars(strip_tags($this->cliente_cargo));
        $this->cliente_trabajo=htmlspecialchars(strip_tags($this->cliente_trabajo));
        $this->tipo_pago=htmlspecialchars(strip_tags($this->tipo_pago));
        $this->fecha_pago=htmlspecialchars(strip_tags($this->fecha_pago));
        $this->interes=htmlspecialchars(strip_tags($this->interes));
        $this->capital=htmlspecialchars(strip_tags($this->capital));
        $this->cuotas=htmlspecialchars(strip_tags($this->cuotas));
        $this->total=htmlspecialchars(strip_tags($this->total));
        $this->pdf_foto=htmlspecialchars(strip_tags($this->pdf_foto));
        $this->pdf_dni=htmlspecialchars(strip_tags($this->pdf_dni));
        $this->pdf_cip=htmlspecialchars(strip_tags($this->pdf_cip));
        $this->pdf_planilla=htmlspecialchars(strip_tags($this->pdf_planilla));
        $this->pdf_voucher=htmlspecialchars(strip_tags($this->pdf_voucher));
        $this->pdf_recibo=htmlspecialchars(strip_tags($this->pdf_recibo));
        $this->pdf_casilla=htmlspecialchars(strip_tags($this->pdf_casilla));
        $this->pdf_transaccion=htmlspecialchars(strip_tags($this->pdf_transaccion));
        $this->pdf_autorizacion=htmlspecialchars(strip_tags($this->pdf_autorizacion));
        $this->pdf_tarjeta=htmlspecialchars(strip_tags($this->pdf_tarjeta));
        $this->pdf_compromiso=htmlspecialchars(strip_tags($this->pdf_compromiso));
        $this->pdf_letra=htmlspecialchars(strip_tags($this->pdf_letra));
        $this->pdf_ddjj=htmlspecialchars(strip_tags($this->pdf_ddjj));
        $this->pdf_otros=htmlspecialchars(strip_tags($this->pdf_otros));
        $this->observacion=htmlspecialchars(strip_tags($this->observacion));


        if($result->execute())
        {
            while($row = $result->fetch(PDO::FETCH_ASSOC))
            {
                extract($row);
                $this->id_credito=$id;
            }
            return true;
        }
        return false;
    }

    function crear_garante(){
        $query = "CALL sp_crearcreditogarante(
            :prcredito,
            :prcliente,
            :prclientetelefono,
            :prclientedireccion,
            :prpdfdni,
            :prpdfcip,
            :prpdfplanilla
        )";

        $result = $this->conn->prepare($query);

        $result->bindParam(":prcredito", $this->id_credito);
        $result->bindParam(":prcliente", $this->cliente);
        $result->bindParam(":prclientetelefono", $this->cliente_direccion);
        $result->bindParam(":prclientedireccion", $this->cliente_telefono);
        $result->bindParam(":prpdfdni", $this->pdf_dni);
        $result->bindParam(":prpdfcip", $this->pdf_cip);
        $result->bindParam(":prpdfplanilla", $this->pdf_planilla);

        $this->id_credito=htmlspecialchars(strip_tags($this->id_credito));
        $this->cliente=htmlspecialchars(strip_tags($this->cliente));
        $this->cliente_direccion=htmlspecialchars(strip_tags($this->cliente_direccion));
        $this->cliente_telefono=htmlspecialchars(strip_tags($this->cliente_telefono));
        $this->pdf_dni=htmlspecialchars(strip_tags($this->pdf_dni));
        $this->pdf_cip=htmlspecialchars(strip_tags($this->pdf_cip));
        $this->pdf_planilla=htmlspecialchars(strip_tags($this->pdf_planilla));


        if($result->execute())
        {
            return true;
        }
        return false;
    }

    function crear_cronograma(){
        $query = "CALL sp_crearcreditocronograma(
            :prcredito,
            :prcapital,
            :printeres,
            :prfechavencimiento
        )";

        $result = $this->conn->prepare($query);

        $result->bindParam(":prcredito", $this->id_credito);
        $result->bindParam(":prcapital", $this->capital);
        $result->bindParam(":printeres", $this->interes);
        $result->bindParam(":prfechavencimiento", $this->fecha);

        $this->id_credito=htmlspecialchars(strip_tags($this->id_credito));
        $this->capital=htmlspecialchars(strip_tags($this->capital));
        $this->interes=htmlspecialchars(strip_tags($this->interes));
        $this->fecha=htmlspecialchars(strip_tags($this->fecha));


        if($result->execute())
        {
            return true;
        }
        return false;
    }

    function crear_cronograma_afiliacion(){
        $query = "CALL sp_crearcreditocronogramaafiliacion(
            :prcredito,
            :prmonto,
            :prcuotas,
            :prprimeracuota
        )";

        $result = $this->conn->prepare($query);

        $result->bindParam(":prcredito", $this->id_credito);
        $result->bindParam(":prmonto", $this->monto);
        $result->bindParam(":prcuotas", $this->total_cuotas);
        $result->bindParam(":prprimeracuota", $this->fecha);

        $this->id_credito=htmlspecialchars(strip_tags($this->id_credito));
        $this->monto=htmlspecialchars(strip_tags($this->monto));
        $this->total_cuotas=htmlspecialchars(strip_tags($this->total_cuotas));
        $this->fecha=htmlspecialchars(strip_tags($this->fecha));


        if($result->execute())
        {
            return true;
        }
        return false;
    }

    function proximo_credito(){
        $query = "CALL sp_seleccionarproximocredito(?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->cliente);

        $result->execute();

        $row = $result->fetch(PDO::FETCH_ASSOC);

        $this->numero=$row['numero'];
    }

    function verificar_afiliacion(){
        $query = "CALL sp_verificarafiliacion(?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->cliente);

        $result->execute();

        $row = $result->fetch(PDO::FETCH_ASSOC);

        $this->codigo=$row['codigo_afiliacion'];
        $this->total_pagado=$row['pagado'];
        $this->total_cuotas=$row['total'];
    }

    function verificar_interes(){
        $query = "CALL sp_verificarinteres(?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->total_pagado);

        $result->execute();

        $row = $result->fetch(PDO::FETCH_ASSOC);

        $this->interes=$row['interes'];
    }

    function seleccionar_parametros_afiliacion(){
      $query = "CALL sp_seleccionarparametroafiliacion()";

      $result = $this->conn->prepare($query);

      $result->execute();

      $row = $result->fetch(PDO::FETCH_ASSOC);

      $this->id=$row['id'];
      $this->monto=$row['monto'];
      $this->tiempo=$row['tiempo'];
      $this->fecha=$row['fecha'];
    }        

    function seleccionar_numero_afiliacion(){
        $query = "CALL sp_seleccionarproximaafiliacion()";

        $result = $this->conn->prepare($query);
  
        $result->execute();
  
        $row = $result->fetch(PDO::FETCH_ASSOC);
  
        $this->numero=$row['numero'];
    }

    // Este SP muestra las ventas y créditos que puede refinanciar
    function read_transacciones(){

        $query = "CALL sp_listartransaccionesxcliente(?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->cliente);

        $result->execute();
        
        $credito_list=array();
        $credito_list["transacciones"]=array();

        $contador = 0;
        
        while($row = $result->fetch(PDO::FETCH_ASSOC))
        {
            extract($row);
            $contador=$contador+1;

            $items = array (
                "numero"=>$contador,
                "id"=>$id,
                "id_tipo"=>$id_tipo,
                "tipo"=>$tipo,
                "fecha"=>$fecha,
                "documento"=>$documento,
                "total"=>$total,
                "monto_pendiente"=>$monto_pendiente,
                "considerar"=>false,
            );
            array_push($credito_list["transacciones"],$items);
        }

        return $credito_list;
    }

    function read_transacciones_cronograma(){
        $query = "CALL sp_listartransaccionesxclientecronograma(?)";

        $result = $this->conn->prepare($query);

        $result->bindParam(1, $this->cliente);

        $result->execute();
        
        $credito_list=array();
        $credito_list['cronograma']=array();

        while($row = $result->fetch(PDO::FETCH_ASSOC))
        {
            extract($row);
            $items = array (
                "tipo" => $tipo,
                "id_transaccion" => $id_transaccion,
                "fecha_vencimiento" => $fecha_vencimiento,
                "cuota_mensual" => $cuota_mensual,
                "capital" => $capital
            );
            array_push($credito_list['cronograma'],$items);
        }

        return $credito_list['cronograma'];
    }

    // Este SP muestra el monto mensual que tiene por pagar el cliente
    function read_cronogramasxcliente(){

        $query = "CALL sp_listartransaccionescronogramaxcliente(?)";
  
        $result = $this->conn->prepare($query);
  
        $result->bindParam(1, $this->cliente);
  
        $result->execute();
        
        $cronograma_list=array();
        $contador = 0;
  
        while($row = $result->fetch(PDO::FETCH_ASSOC))
        {
            extract($row);
            $contador=$contador+1;
            $item = array (
                "numero"=>$contador,
                "fecha_vencimiento"=>$fecha_vencimiento,
                "cuota_mensual"=>$cuota_mensual
            );
            array_push($cronograma_list,$item);
        }
  
        return $cronograma_list;
    }

    function actualizar_transacciones_refinanciadas(){
        $query = "CALL sp_actualizartransaccionrefinanciada(
            :prnuevocredito,
            :ptipo,
            :prtransaccion
        )";

        $result = $this->conn->prepare($query);

        $result->bindParam(":prnuevocredito", $this->id_credito);
        $result->bindParam(":ptipo", $this->tipo);
        $result->bindParam(":prtransaccion", $this->id_transaccion);

        $this->id_credito=htmlspecialchars(strip_tags($this->id_credito));
        $this->tipo=htmlspecialchars(strip_tags($this->tipo));
        $this->id_transaccion=htmlspecialchars(strip_tags($this->id_transaccion));

        if($result->execute())
        {
            return true;
        }
        return false;
    }

    function eliminar_credito(){
        $query = "CALL sp_eliminarcredito(
            :prcredito
        )";

        $result = $this->conn->prepare($query);

        $result->bindParam(":prcredito", $this->id_credito);

        $this->id_credito=htmlspecialchars(strip_tags($this->id_credito));

        if($result->execute())
        {
            return true;
        }
        return false;
    }

}

?>